<?php

namespace App\Http\Controllers;

use App\Models\Folder;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Yajra\DataTables\Facades\Datatables;

class FolderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = Folder::query(); // Remove the eager loading of 'creator' relationship
            return Datatables::eloquent($query)
                ->make(true);
        }

        return view('folders.list');
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('folders.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        Folder::create([
            'name' => $request->name,
            // 'created_by' => $request->created_by, // Assuming 'created_by' is in the request

            // Add other fields as needed
        ]);

        return redirect()->route('folders.index')
            ->with('success', 'Folder created successfully');
    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $folder = Folder::find($id);
        return view('folders.edit', compact('folder'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $folder = Folder::findOrFail($id);

        $folder->update([
            'name' => $request->name,
            // 'created_by' => $request->created_by, // Assuming 'created_by' is in the request
            // Add other fields as needed
        ]);

        return redirect()->route('folders.index')
            ->with('success', 'Folder updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $folder = Folder::findOrFail($id);
        $folder->delete();

        return redirect()->route('folders.index')
            ->with('success', 'Folder deleted successfully');
    }
}
