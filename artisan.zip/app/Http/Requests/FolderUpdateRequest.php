<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FolderUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true; // Set this to true if you have authorization logic
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'parent_id' => 'nullable|exists:folders,id',
            'name' => 'required|string|max:255',
            'created_by' => 'required|exists:users,id', // Validation rule for created_by
            // Add other validation rules for additional fields as needed
        ];
    }
}
