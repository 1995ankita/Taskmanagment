<?php

namespace App\Http\Controllers;

use App\Models\Files;
use App\Models\Folder;
use App\Models\UserFiles;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Yajra\DataTables\Facades\Datatables;

class FilesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = Files::with(['folder']);
            return Datatables::eloquent($query)
                ->addColumn('folder_name', function ($file) {
                    return optional($file->folder)->name;
                })
                ->addColumn('permissions', function ($file) {
                    // Fetch and format permissions for the file
                    $permissions = UserFiles::where('file_id', $file->id)
                        ->join('permissions', 'user_files.permission_id', '=', 'permissions.id')
                        ->pluck('name')
                        ->implode(', ');
                    return $permissions;
                })
                // Exclude 'path' and 'extension' from the DataTable
                ->editColumn('path', function ($file) {
                    return ''; // You can customize this as needed
                })
                ->editColumn('extension', function ($file) {
                    return ''; // You can customize this as needed
                })
                ->make(true);
        }

        return view('files.list');
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $folders = Folder::all();
        return view('files.create', compact('folders'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validate the request here if needed

        $file = $request->file('file');
        $uuid = \Illuminate\Support\Str::uuid();

        // Generate a unique filename with extension
        $filename = $uuid . '_' . $file->getClientOriginalName();
        $extension = $file->getClientOriginalExtension();
        $filenameWithExtension = $filename . '.' . $extension;

        // Move the file to the public storage directory
        $file->move(public_path('storage/' . $uuid), $filenameWithExtension);

        // Store only necessary information in the database
        Files::create([
            'uuid' => $uuid,
            'folder_id' => $request->folder_id,
            'path' => 'storage/' . $uuid,
            'name' => $filenameWithExtension,
            'display_name' => $request->display_name,
            'extension' => $extension,
            'created_by' => auth()->id(), // Assuming the current authenticated user creates the file
        ]);

        return redirect()->route('files.index')
            ->with('success', 'File created successfully');
    }


    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $file = Files::findOrFail($id);
        $folders = Folder::all();

        return view('files.edit', compact('file', 'folders'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $file = Files::findOrFail($id);

        // Validate the request here if needed

        // Check if a new file is uploaded
        if ($request->hasFile('file')) {
            // A new file is uploaded, handle file update
            $newFile = $request->file('file');
            $uuid = $file->uuid;

            // Generate a unique filename with extension
            $filename = $uuid . '_' . $newFile->getClientOriginalName();
            $extension = $newFile->getClientOriginalExtension();
            $filenameWithExtension = $filename . '.' . $extension;

            // Move the file to the public storage directory
            $newFile->move(public_path('storage/' . $uuid), $filenameWithExtension);

            // Remove the old file
            Storage::delete($file->path . '/' . $file->name);

            // Update necessary information in the database
            $file->update([
                'folder_id' => $request->folder_id,
                'path' => 'storage/' . $uuid,
                'name' => $filenameWithExtension,
                'display_name' => $request->display_name,
                'extension' => $extension,
                'created_by' => auth()->id(), // Assuming the current authenticated user updates the file
                // Add other fields as needed
            ]);


            return redirect()->route('files.index')
                ->with('success', 'File updated successfully');
        }

        // If no new file is uploaded, update other information without changing the file
        $file->update([
            'folder_id' => $request->folder_id,
            'display_name' => $request->display_name,
            // Add other fields as needed
        ]);

        return redirect()->route('files.index')
            ->with('success', 'File information updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $file = Files::findOrFail($id);
        $file->delete();

        return redirect()->route('files.index')
            ->with('success', 'File deleted successfully');
    }
}
